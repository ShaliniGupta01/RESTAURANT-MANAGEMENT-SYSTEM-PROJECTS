
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Thanks.css";

export default function Thanks() {
  const navigate = useNavigate();
  const [countdown, setCountdown] = useState(3);

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => prev - 1);
    }, 1000);

    if (countdown === 0) {
      clearInterval(timer);
      navigate("/");
    }

    return () => clearInterval(timer);
  }, [countdown, navigate]);

  return (
    <div className="thanks-page">
      <h2>Thanks For Ordering</h2>

      <div className="checkmark-circle">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="36"
          height="36"
          viewBox="0 0 24 24"
          fill="none"
          stroke="#000"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <polyline points="20 6 9 17 4 12" />
        </svg>
      </div>

      <p className="redirect-text">Redirecting in {countdown}</p>
    </div>
  );
}


// // // // import React, { useEffect, useState } from "react";
// // // // import { useLocation, useNavigate } from "react-router-dom";
// // // // import "./Thanks.css";

// // // // export default function Thanks() {
// // // //   const { state } = useLocation(); // gets orderId and type from navigate()
// // // //   const navigate = useNavigate();
// // // //   const [countdown, setCountdown] = useState(3);

// // // //   useEffect(() => {
// // // //     const timer = setInterval(() => {
// // // //       setCountdown((prev) => prev - 1);
// // // //     }, 1000);

// // // //     if (countdown === 0) {
// // // //       clearInterval(timer);
// // // //       navigate("/"); // redirect after 3 sec
// // // //     }

// // // //     return () => clearInterval(timer);
// // // //   }, [countdown, navigate]);

// // // //   return (
// // // //     <div className="thanks-page">
// // // //       <h2>🎉 Thank You!</h2>
// // // //       <p>Your {state?.type || "order"} has been placed successfully!</p>

// // // //       {state?.orderId && (
// // // //         <p>
// // // //           Order ID: <strong>{state.orderId}</strong>
// // // //         </p>
// // // //       )}

// // // //       <div className="checkmark-circle">
// // // //         <svg
// // // //           xmlns="http://www.w3.org/2000/svg"
// // // //           width="36"
// // // //           height="36"
// // // //           viewBox="0 0 24 24"
// // // //           fill="none"
// // // //           stroke="#000"
// // // //           strokeWidth="3"
// // // //           strokeLinecap="round"
// // // //           strokeLinejoin="round"
// // // //         >
// // // //           <polyline points="20 6 9 17 4 12" />
// // // //         </svg>
// // // //       </div>

// // // //       <p className="redirect-text">Redirecting in {countdown}...</p>

// // // //       <button className="btn-home" onClick={() => navigate("/")}>
// // // //         Go to Home Now
// // // //       </button>
// // // //     </div>
// // // //   );
// // // // }


// // // import React, { useEffect, useState } from "react";
// // // import { useLocation, useNavigate } from "react-router-dom";
// // // import "./Thanks.css";

// // // export default function Thanks() {
// // //   const location = useLocation();
// // //   const navigate = useNavigate();
// // //   const [countdown, setCountdown] = useState(3);

// // //   // ✅ Safely extract order data
// // //   const orderId = location.state?.orderId || "N/A";
// // //   const type = location.state?.type || "Order";

// // //   // ✅ Auto redirect
// // //   useEffect(() => {
// // //     if (countdown <= 0) {
// // //       navigate("/");
// // //       return;
// // //     }
// // //     const timer = setTimeout(() => setCountdown((c) => c - 1), 1000);
// // //     return () => clearTimeout(timer);
// // //   }, [countdown, navigate]);

// // //   return (
// // //     <div className="thanks-page">
// // //       <h2>🎉 Thank You!</h2>
// // //       <p>
// // //         Your <strong>{type}</strong> has been placed successfully.
// // //       </p>

// // //       {orderId !== "N/A" && (
// // //         <p>
// // //           Order ID: <strong>{orderId}</strong>
// // //         </p>
// // //       )}

// // //       <div className="checkmark-circle">
// // //         <svg
// // //           xmlns="http://www.w3.org/2000/svg"
// // //           width="40"
// // //           height="40"
// // //           viewBox="0 0 24 24"
// // //           fill="none"
// // //           stroke="#2ecc71"
// // //           strokeWidth="3"
// // //           strokeLinecap="round"
// // //           strokeLinejoin="round"
// // //         >
// // //           <polyline points="20 6 9 17 4 12" />
// // //         </svg>
// // //       </div>

// // //       <p className="redirect-text">Redirecting in {countdown} seconds...</p>

// // //       <button className="btn-home" onClick={() => navigate("/")}>
// // //         Go to Home Now
// // //       </button>
// // //     </div>
// // //   );
// // // }


// // import React, { useEffect, useState } from "react";
// // import { useLocation, useNavigate } from "react-router-dom";
// // import "./Thanks.css";

// // export default function Thanks() {
// //   const location = useLocation();
// //   const navigate = useNavigate();
// //   const [countdown, setCountdown] = useState(3);

// //   const orderId = location.state?.orderId || null;
// //   const type = location.state?.type || "order";

// //   useEffect(() => {
// //     if (countdown <= 0) {
// //       navigate("/");
// //       return;
// //     }
// //     const t = setTimeout(() => setCountdown(c => c - 1), 1000);
// //     return () => clearTimeout(t);
// //   }, [countdown, navigate]);

// //   return (
// //     <div className="thanks-page">
// //       <h2>🎉 Thank You!</h2>
// //       <p>Your <strong>{type}</strong> has been placed successfully.</p>
// //       {orderId && <p>Order ID: <strong>{orderId}</strong></p>}

// //       <div className="checkmark-circle" style={{ margin: 18 }}>
// //         <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="#2ecc71" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
// //           <polyline points="20 6 9 17 4 12" />
// //         </svg>
// //       </div>

// //       <p className="redirect-text">Redirecting to home in {countdown}...</p>
// //       <button className="btn-home" onClick={() => navigate("/")}>Go to Home Now</button>
// //     </div>
// //   );
// // }



// import React, {  useState } from "react";
// import { useNavigate } from "react-router-dom";
// import api from "../../api/axios";
// import CartSummary from "../../components/CartSummary/Cart";
// import CookingInstruction from "../../components/CookingInstruction/CookingInstruction";
// import SearchBar from "../../components/SearchBar/SearchBar";
// import "./Checkout.css";

// export default function Checkout() {
//   const navigate = useNavigate();
//   const [cart, setCart] = useState(JSON.parse(localStorage.getItem("rms_cart")) || []);
//   // eslint-disable-next-line no-unused-vars
//   const [user, setUser] = useState(JSON.parse(localStorage.getItem("rms_user")) || {});
//   // eslint-disable-next-line no-unused-vars
//   const [orderType, setOrderType] = useState("Dine In");
//   const [instructions, setInstructions] = useState("");

//   const computeTotals = () => {
//     const itemsTotal = cart.reduce((s, c) => s + c.qty * c.price, 0);
//     const delivery = orderType === "Take Away" ? 50 : 0;
//     const taxes = 5;
//     return { itemsTotal, delivery, taxes, grandTotal: itemsTotal + delivery + taxes };
//   };

//   const handlePlaceOrder = async () => {
//     if (cart.length === 0) {
//       alert("⚠️ Your cart is empty!");
//       return;
//     }

//     const totals = computeTotals();
//     const orderData = {
//       orderId: `ODR-${Date.now()}`,
//       type: orderType,
//       userId: user?._id || "guest_user",
//       restaurantId: user?.restaurantId || "default_restaurant",
//       items: cart,
//       totalAmount: totals.grandTotal,
//       instructions,
//       status: "Pending",
//     };

//     try {
//       const res = await api.post("/orders", orderData);
//       if (res.status === 201 || res.status === 200) {
//         localStorage.removeItem("rms_cart");
//         setCart([]);
//         navigate("/thanks", { state: { orderId: res.data?._id || orderData.orderId, type: orderType } });
//       }
//     } catch (err) {
//       console.error("❌ Order creation failed:", err);
//       alert("Failed to place order. Try again.");
//     }
//   };

//   return (
//     <div className="checkout-shell">
//       <SearchBar />
//       <div className="cart-items">
//         {cart.map((it) => (
//           <div key={it.id} className="cart-item">
//             <img
//               src={it.image?.startsWith("http") ? it.image : `http://localhost:5000${it.image}`}
//               alt={it.name}
//               className="cart-item-img"
//             />
//             <div className="cart-info">
//               <div>{it.name}</div>
//               <div>₹{it.price}</div>
//             </div>
//           </div>
//         ))}
//       </div>

//       <CartSummary
//         cart={cart}
//         user={user}
//         orderType={orderType}
//         onPlaceOrder={handlePlaceOrder} // 👈 important
//       />

//       <CookingInstruction
//         visible={false}
//         onSave={setInstructions}
//       />
//     </div>
//   );
// }
