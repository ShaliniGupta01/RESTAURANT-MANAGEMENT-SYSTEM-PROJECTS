
import React, { useState, useRef } from "react";
import { useSwipeable } from "react-swipeable";
import "./Cart.css";

export default function CartSummary({ cart, user, orderType, onPlaceOrder }) {
  const [swiped, setSwiped] = useState(false);
  const sliderRef = useRef(null);
  

  const handleOrder = () => {
    if (!swiped) {
      setSwiped(true);
      onPlaceOrder?.();
      setTimeout(() => setSwiped(false), 1500);
    }
  };

  const handlers = useSwipeable({
    onSwipedRight: handleOrder,
    preventScrollOnSwipe: true,
    trackMouse: true,
  });

  const itemsTotal = cart.reduce((s, c) => s + c.qty * c.price, 0);
  const delivery = orderType === "Take Away" ? 50 : 0;
  const taxes = 5;
  const grandTotal = itemsTotal + delivery + taxes;

  return (
     
    <div className="summary-card">
      {/* ------ PRICE SECTION ------ */}
     
      <div className="price-section">
        <div className="row">
          <span>Item Total</span>
          <span>₹{itemsTotal.toFixed(2)}</span>
        </div>

        {orderType === "Take Away" && (
          <div className="row delivery">
            <span>Delivery Charge</span>
            <span>₹{delivery.toFixed(2)}</span>
          </div>
        )}

        <div className="row">
          <span>Taxes</span>
          <span>₹{taxes.toFixed(2)}</span>
        </div>

        <div className="row total">
          <strong>Grand Total</strong>
          <strong>₹{grandTotal.toFixed(2)}</strong>
        </div>
      </div>

      {/* ------ YOUR DETAILS SECTION ------ */}
      <div className="your-details">
        <div className="yd-title">Your details</div>
        <div className="yd-info">
          {user?.name} • {user?.phone}
        </div>

        <div className="user-line" />

        {orderType === "Take Away" ? (
          <div className="yd-extra">
            <div className="yd-row">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="icon-green"
                viewBox="0 0 24 24"
                fill="none"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 1 1 18 0z" />
                <circle cx="12" cy="10" r="3" />
              </svg>
              <span>
                Delivery at Home — {user?.address || "Fetching location..."}
              </span>
            </div>

            <div className="yd-row">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="icon-green"
                viewBox="0 0 24 24"
                fill="none"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <circle cx="12" cy="12" r="10" />
                <polyline points="12 6 12 12 16 14" />
              </svg>
              <span>
                Delivery in <strong>42 mins</strong>
              </span>
            </div>
          </div>
        ) : (
          <div className="yd-row">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="icon-green"
              viewBox="0 0 24 24"
              fill="none"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M4 21v-7a4 4 0 0 1 4-4h8a4 4 0 0 1 4 4v7" />
              <path d="M12 12V3" />
              <path d="M8 3h8" />
            </svg>
            <span>Dining in restaurant</span>
          </div>
        )}
      </div>

      {/* ------ SWIPE TO ORDER ------ */}
      <div
        className="swipe-track"
        {...handlers}
        ref={sliderRef}
        onClick={handleOrder}
      >
        <div className={`swipe-thumb ${swiped ? "swiped" : ""}`}>➡</div>
        <span className={`swipe-text ${swiped ? "done" : ""}`}>
          {swiped ? "Order Placed!" : "Swipe to Order"}
        </span>
      </div>
    </div>
  );
}


// // import React, { useState, useRef } from "react";
// // import { useSwipeable } from "react-swipeable";
// // import { useNavigate } from "react-router-dom";
// // import api from "../../api/axios";
// // import "./Cart.css";

// // export default function CartSummary({ cart, user, orderType }) {
// //   const [swiped, setSwiped] = useState(false);
// //   const sliderRef = useRef(null);
// //   const navigate = useNavigate();

// //   const itemsTotal = cart.reduce((s, c) => s + c.qty * c.price, 0);
// //   const delivery = orderType === "Take Away" ? 50 : 0;
// //   const taxes = 5;
// //   const grandTotal = itemsTotal + delivery + taxes;

// //   const handleOrder = async () => {
// //     if (swiped || cart.length === 0) return;
// //     setSwiped(true);

// //     try {
// //       const orderData = {
// //         type: orderType,
// //         items: cart.map((item) => ({
// //           name: item.name,
// //           quantity: item.qty,
// //           price: item.price,
// //         })),
// //         totalAmount: grandTotal,
// //         clientName: user?.name || "Guest",
// //         phoneNumber: user?.phone || "N/A",
// //         address: user?.address || "",
// //         instructions: "No special instructions",
// //         user,
// //       };

// //       const res = await api.post("/orders", orderData);
// //       console.log("✅ Order saved:", res.data);

// //       // Optional: clear local cart
// //       // localStorage.removeItem("rms_cart");

// //       // ✅ Redirect after delay to allow swipe animation
// //      setTimeout(() => {
// //  navigate("/thanks", {
// //   state: { orderId: res.data?.order?._id, type: orderType },
// // });

// // }, 1500);
// // ;
// //     } catch (err) {
// //       console.error("❌ Error placing order:", err);
// //       alert("Failed to place order. Please try again.");
// //       setSwiped(false);
// //     }
// //   };

// //   const handlers = useSwipeable({
// //     onSwipedRight: handleOrder,
// //     preventScrollOnSwipe: true,
// //     trackMouse: true,
// //   });

// //   return (
// //     <div className="summary-card">
// //       {/* ------ PRICE SECTION ------ */}
// //       <div className="price-section">
// //         <div className="row">
// //           <span>Item Total</span>
// //           <span>₹{itemsTotal.toFixed(2)}</span>
// //         </div>

// //         {orderType === "Take Away" && (
// //           <div className="row delivery">
// //             <span>Delivery Charge</span>
// //             <span>₹{delivery.toFixed(2)}</span>
// //           </div>
// //         )}

// //         <div className="row">
// //           <span>Taxes</span>
// //           <span>₹{taxes.toFixed(2)}</span>
// //         </div>

// //         <div className="row total">
// //           <strong>Grand Total</strong>
// //           <strong>₹{grandTotal.toFixed(2)}</strong>
// //         </div>
// //       </div>

// //       {/* ------ YOUR DETAILS SECTION ------ */}
// //       <div className="your-details">
// //         <div className="yd-title">Your details</div>
// //         <div className="yd-info">
// //           {user?.name || "Guest"} • {user?.phone || "N/A"}
// //         </div>

// //         <div className="user-line" />

// //         {orderType === "Take Away" ? (
// //           <div className="yd-extra">
// //             <div className="yd-row">
// //               <svg
// //                 xmlns="http://www.w3.org/2000/svg"
// //                 className="icon-green"
// //                 viewBox="0 0 24 24"
// //                 fill="none"
// //                 strokeWidth="2"
// //                 strokeLinecap="round"
// //                 strokeLinejoin="round"
// //               >
// //                 <path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 1 1 18 0z" />
// //                 <circle cx="12" cy="10" r="3" />
// //               </svg>
// //               <span>
// //                 Delivery at Home — {user?.address || "Fetching location..."}
// //               </span>
// //             </div>

// //             <div className="yd-row">
// //               <svg
// //                 xmlns="http://www.w3.org/2000/svg"
// //                 className="icon-green"
// //                 viewBox="0 0 24 24"
// //                 fill="none"
// //                 strokeWidth="2"
// //                 strokeLinecap="round"
// //                 strokeLinejoin="round"
// //               >
// //                 <circle cx="12" cy="12" r="10" />
// //                 <polyline points="12 6 12 12 16 14" />
// //               </svg>
// //               <span>
// //                 Delivery in <strong>42 mins</strong>
// //               </span>
// //             </div>
// //           </div>
// //         ) : (
// //           <div className="yd-row">
// //             <svg
// //               xmlns="http://www.w3.org/2000/svg"
// //               className="icon-green"
// //               viewBox="0 0 24 24"
// //               fill="none"
// //               strokeWidth="2"
// //               strokeLinecap="round"
// //               strokeLinejoin="round"
// //             >
// //               <path d="M4 21v-7a4 4 0 0 1 4-4h8a4 4 0 0 1 4 4v7" />
// //               <path d="M12 12V3" />
// //               <path d="M8 3h8" />
// //             </svg>
// //             <span>Dining in restaurant</span>
// //           </div>
// //         )}
// //       </div>

// //       {/* ------ SWIPE TO ORDER ------ */}
// //       <div
// //         className="swipe-track"
// //         {...handlers}
// //         ref={sliderRef}
// //         onClick={handleOrder}
// //       >
// //         <div className={`swipe-thumb ${swiped ? "swiped" : ""}`}>➡</div>
// //         <span className={`swipe-text ${swiped ? "done" : ""}`}>
// //           {swiped ? "Order Placed!" : "Swipe to Order"}
// //         </span>
// //       </div>
// //     </div>
// //   );
// // }


// import React, { useState, useRef } from "react";
// import { useSwipeable } from "react-swipeable";
// import { useNavigate } from "react-router-dom";
// import "./Cart.css";

// export default function CartSummary({ cart = [], user = {}, orderType = "Dine In", onPlaceOrder }) {
//   const [swiped, setSwiped] = useState(false);
//   const sliderRef = useRef(null);
//   const navigate = useNavigate();

//   const itemsTotal = cart.reduce((s, c) => s + c.qty * c.price, 0);
//   const delivery = orderType === "Take Away" ? 50 : 0;
//   const taxes = 5;
//   const grandTotal = itemsTotal + delivery + taxes;

//   const handleOrder = async () => {
//     if (swiped) return;
//     setSwiped(true);

//     // If caller provided onPlaceOrder, call it and await result.
//     try {
//       let createdOrder = null;
//       if (typeof onPlaceOrder === "function") {
//         // onPlaceOrder should throw on failure; handle below
//         createdOrder = await onPlaceOrder();
//         console.log("Order created:", createdOrder);
//       }

//       // Clear local cart (onPlaceOrder may have already done this)
//       try {
//         localStorage.removeItem("rms_cart");
//       } catch (e) {
//         /* ignore */
//       }

//       // small delay so user sees the "Order Placed!" state
//       setTimeout(() => {
//         const orderId = createdOrder?._id || createdOrder?.orderId || null;
//         navigate("/thanks", { state: { orderId, type: orderType } });
//       }, 900);
//     } catch (err) {
//       console.error("Place order failed:", err);
//       // still navigate to thanks page (optional) but inform user
//       alert("Failed to place order with server. Redirecting to confirmation page.");
//       setTimeout(() => {
//         navigate("/thanks", { state: { type: orderType } });
//       }, 900);
//     } finally {
//       // reset swipe UI after a moment
//       setTimeout(() => setSwiped(false), 2200);
//     }
//   };

//   const handlers = useSwipeable({
//     onSwipedRight: handleOrder,
//     preventScrollOnSwipe: true,
//     trackMouse: true,
//   });

//   return (
//     <div className="summary-card">
//       <div className="price-section">
//         <div className="row">
//           <span>Item Total</span>
//           <span>₹{itemsTotal.toFixed(2)}</span>
//         </div>

//         {orderType === "Take Away" && (
//           <div className="row delivery">
//             <span>Delivery Charge</span>
//             <span>₹{delivery.toFixed(2)}</span>
//           </div>
//         )}

//         <div className="row">
//           <span>Taxes</span>
//           <span>₹{taxes.toFixed(2)}</span>
//         </div>

//         <div className="row total">
//           <strong>Grand Total</strong>
//           <strong>₹{grandTotal.toFixed(2)}</strong>
//         </div>
//       </div>

//       <div className="your-details">
//         <div className="yd-title">Your details</div>
//         <div className="yd-info">{user?.name || "Guest"} • {user?.phone || "N/A"}</div>

//         <div className="user-line" />

//         {orderType === "Take Away" ? (
//           <div className="yd-extra">
//             <div className="yd-row">🏠 Delivery at Home — {user?.address || "Fetching location..."}</div>
//             <div className="yd-row">⏱ Delivery in <strong>40–45 mins</strong></div>
//           </div>
//         ) : (
//           <div className="yd-row">🍽 Dining in restaurant</div>
//         )}
//       </div>

//       <div className="swipe-track" {...handlers} ref={sliderRef} onClick={handleOrder}>
//         <div className={`swipe-thumb ${swiped ? "swiped" : ""}`}>➡</div>
//         <span className={`swipe-text ${swiped ? "done" : ""}`}>{swiped ? "Order Placed!" : "Swipe to Order"}</span>
//       </div>
//     </div>
//   );
// }



// import React, { useState, useRef } from "react";
// import { useSwipeable } from "react-swipeable";
// import "./Cart.css";

// export default function Cart({ cart, user, orderType, onPlaceOrder }) {
//   // eslint-disable-next-line no-unused-vars
//   const [swiped, setSwiped] = useState(false);
//   const sliderRef = useRef(null);

//   const handlers = useSwipeable({
//     onSwipedRight: () => {
//       setSwiped(true);
//       if (typeof onPlaceOrder === "function") onPlaceOrder();
//     },
//     preventScrollOnSwipe: true,
//     trackMouse: true,
//   });

//   const totals = cart.reduce((sum, i) => sum + i.price * i.qty, 0);

//   return (
//     <div {...handlers} ref={sliderRef} className="cart-summary">
//       <div className="cart-total">
//         <p>Total: ₹{totals}</p>
//       </div>
//       <button className="place-order-btn" onClick={onPlaceOrder}>
//         Swipe or Tap to Order
//       </button>
//     </div>
//   );
// }
